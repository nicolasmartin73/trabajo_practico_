
package concesionaria;

import java.text.DecimalFormat;

public abstract class Vehiculo implements Comparable<Vehiculo>{
    DecimalFormat formateador = new DecimalFormat("#,###.00");
    private String marca;
    private String modelo;
    private double precio;
    
    public Vehiculo(String marca, String modelo, double precio){
        this.marca=marca;
        this.modelo=modelo;
        this.precio=precio;
    }

    @Override
    public String toString() {
        return "Vehiculo: " + "Marca: " + marca + ", Modelo: " + modelo + ", Precio: " + precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getPrecio() {
        return precio;
    }
    
    public String compare(){
     return marca + modelo + precio;
    }
    
    
}
