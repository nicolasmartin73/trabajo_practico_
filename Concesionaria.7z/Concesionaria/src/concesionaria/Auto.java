
package concesionaria;

import java.text.DecimalFormat;

public class Auto extends Vehiculo{
    DecimalFormat formateador = new DecimalFormat("#,###.00");
    int puertas;    
    
    public Auto(String marca, String modelo, double precio, int puertas){
    super(marca, modelo, precio);
    this.puertas=puertas;
    }

    @Override
    public String toString() {
        return "Marca: " + super.getMarca() + " // Modelo: " + super.getModelo() + " // Puertas: " + puertas + " // Precio: $" + formateador.format(super.getPrecio());
    }    

    @Override
    public int compareTo(Vehiculo v){
        return this.compare().compareTo(v.compare());
    }
    
}
